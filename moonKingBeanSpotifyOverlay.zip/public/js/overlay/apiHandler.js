function apiInit(user){
    //make a fetch call with request mode no-cors using jQuery

    $.ajax({
        url: "overlayinfo/?user=" + user,
        type: "GET",
        
        success: function(data){
            userAccepted(user, data)
        },
        error: function(xhr, status, error){
             var sick = JSON.parse(xhr.responseText);
             if (sick.message == "No user provided" | sick.message == "No user exists") noUserExists()// Log the error response
        }
        // make it when the api returns code 404, show an error


    })
}


function noUserExists(){
    const overlayContainer = document.querySelector('.overlay-container');
    const songText = document.querySelector('.song-name-text');
    overlayContainer.classList.add('overlay-container-error');
    overlayContainer.classList.remove('overlay-container');

    songText.textContent = "ERR: No user exists!";

}

function userAccepted(user, data){
    var string = `${data.message}`
    if (string.includes(user)) {
        getInfo(user)
        setInterval(() => {
            getInfo(user)
    }, 1000);
    }
}   

function getInfo(user){
    fetch("nowplaying/?user=" + user)
    .then((response) => response.json())
    .then((data) => {
        const songText = document.querySelector('.song-name-text');
        const artistText = document.querySelector('.artist-name-text');
        const songImg = document.querySelector('.cover');
        const timeText = document.querySelector('.overlay-timer-text');
        const durationText = document.querySelector('.overlay-timer-text2');
        const timeBar = document.querySelector('.overlay-timer-bar');
        var info = data.data;
        songText.textContent = info.song_name;
        artistText.textContent = info.artists[0].name;
        if (info.song_cover == null) {
            songImg.src = "https://i.ibb.co/0jyJpX8/placeholder.png";
        }
        if (info.song_cover != songImg.src){
            songImg.src = info.song_cover;
        }
        // convert time to mm:ss
        timeText.textContent = convertTime(info.progress);
        durationText.textContent = convertTime(info.totalMS);
        var timeBarWidth = (info.progress / info.totalMS) * 385; // Max width is 385px
        timeBar.style.width = Math.min(timeBarWidth, 385) + "px";
    })
        
}

function convertTime(ms) {
    var ms = ms / 1000;
    var mins = Math.floor(ms / 60);
    var secs = Math.floor(ms % 60);
    if (secs < 10) {
        secs = "0" + secs;
    }
    if (mins < 10) {
        mins = "0" + mins;
    }

    return mins + ":" + secs;
}



setInterval(() => {
    


  const maxWidth = 375;
  const songText = document.querySelector(".song-name-text");
  
  if (  songText.getBoundingClientRect().width > maxWidth
    
  ) {
    songText.style.animation = "scrollText 6.78s linear infinite alternate";
  } else {
    songText.style.animation = "none";
  }

}, 10)


