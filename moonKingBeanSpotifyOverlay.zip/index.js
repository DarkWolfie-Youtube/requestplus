const express = require("express");
const app = express();
const request = require('request');
const path = require("node:path");
const fs = require("node:fs");
const log = require("./logger.js");
const cors = require("cors");
const ejs = require('ejs');
const bodyParser = require('body-parser');
const cookieParser = require("cookie-parser");
var generateRandomString = function(length) {
    var text = '';
    var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  
    for (var i = 0; i < length; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
  };
const querystring = require('node:querystring');
var session        = require('express-session');
var passport       = require('passport');
var OAuth2Strategy = require('passport-oauth').OAuth2Strategy;
const Sequelize = require('sequelize');
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const wait = require('node:timers/promises').setTimeout;
const SESSION_SECRET   = generateRandomString(32);
const data = new Sequelize('database', 'user', 'password', {
	host: 'localhost',
	dialect: 'sqlite',
	logging: false,
	// SQLite only
	storage: 'spotify_overlay_data.sqlite',
});
const DBEdit = data.define('spotify_data', {
	user: Sequelize.STRING,
    stoken: Sequelize.STRING,
    expires_at: Sequelize.DATE,
    srefresh_token: Sequelize.STRING,
    stoken_renew: Sequelize.BOOLEAN,
    ttoken: Sequelize.STRING,
    trefresh_token: Sequelize.STRING,
    texpires_at: Sequelize.DATE

});

const DBEdit2 = data.define('state_data', {
    state: Sequelize.STRING,
    user: Sequelize.STRING,

});
const sclient_id = config.options.spotify.client_id;
const sclient_secret = config.options.spotify.client_secret;
const tclient_id = config.options.twitch.client_id;
const tclient_secret = config.options.twitch.client_secret;
const DBEdit3 = data.define('user_settings', {
	user: Sequelize.STRING,
    style: Sequelize.STRING


});
var stateKey = 'spotify_auth_state';
var redirect_uri1 = 'https://overlay.darkwolfie.com/scallback';
var redirect_uri2 = 'https://overlayapi.darkwolfie.com/tcallback';
var testing = "http://localhost:3000/tcallback"

// Override passport profile function to get user profile from Twitch API
OAuth2Strategy.prototype.userProfile = function(accessToken, done) {
    var options = {
      url: 'https://api.twitch.tv/helix/users',
      method: 'GET',
      headers: {
        'Client-ID': tclient_id,
        'Accept': 'application/vnd.twitchtv.v5+json',
        'Authorization': 'Bearer ' + accessToken
      }
    };
  
    request(options, function (error, response, body) {
      if (response && response.statusCode == 200) {
        done(null, JSON.parse(body));
      } else {
        done(JSON.parse(body));
      }
    });
  }
  
  passport.serializeUser(function(user, done) {
      done(null, user);
  });
  
  passport.deserializeUser(function(user, done) {
      done(null, user);
  });
  passport.use('twitch', new OAuth2Strategy({
    authorizationURL: 'https://id.twitch.tv/oauth2/authorize',
    tokenURL: 'https://id.twitch.tv/oauth2/token',
    clientID: tclient_id,
    clientSecret: tclient_secret,
    callbackURL: redirect_uri2,
    state: true
  },
  async function(accessToken, refreshToken, data, profile, done) {
    profile.accessToken = accessToken;
    profile.refreshToken = refreshToken;
    profile.expiresIn = data.expires_in
    console.log(profile)

    // Securely store user profile in your DB
    //User.findOrCreate(..., function(err, user) {
    //  done(err, user);
    //});
    var found = await DBEdit.findOrCreate({where: {user: profile.data[0].login},
        defaults: {
            ttoken: accessToken,
            trefresh_token: refreshToken,
            texpires_at: new Date().setSeconds(new Date().getSeconds() + profile.expiresIn)
        }}
    )
    console.log(new Date().setSeconds(new Date().getSeconds() + profile.expiresIn))
    if (found) {
        DBEdit.update({ttoken: accessToken, trefresh_token: refreshToken, texpires_at: new Date().setSeconds(new Date().getSeconds() + profile.expiresIn)}, {where: {user: profile.data[0].login}})
    }

    done(null, profile);
  }
));


app.use(express.static(path.join(__dirname, "public")))
.use(cors())
.use(cookieParser())
.use(session({secret: SESSION_SECRET, resave: false, saveUninitialized: false}))
.use(passport.initialize())
.use(passport.session())
.use(bodyParser.json())
.use(bodyParser.urlencoded({ extended: true }));

app.set("view engine", "ejs");

app.get("/", (req, res) => {
    if(req.session && req.session.passport && req.session.passport.user) {
        res.render("indexl");
      } else {
        res.render("index");
      }
})


app.get("/overlay", async (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    const html = await ejs.renderFile("views/overlay.ejs", {req: req, DBEdit: DBEdit3}, {async: true});
    res.send(html)
})

app.listen(3000, () => {
    log.info("Listening on port 3000");
    DBEdit.sync()
    DBEdit2.sync()
    DBEdit3.sync()
})




app.get("/signup", async (req, res) => {
        res.redirect('/twitch_check')

});

app.get('/slogin', async (req, res) => {
    if(req.session && req.session.passport && req.session.passport.user) {
        console.log(req.session.passport.user.data[0].login)
      
      
        var state = generateRandomString(16);
        var user = `${req.session.passport.user.data[0].login}`;
        var cool = await DBEdit2.create({state: state, user: user})
        // your application requests authorization
        var scope = 'user-read-private user-read-email app-remote-control streaming user-read-playback-state user-modify-playback-state user-read-currently-playing';
        res.redirect('https://accounts.spotify.com/authorize?' +
          querystring.stringify({
            response_type: 'code',
            client_id: sclient_id,
            scope: scope,
            redirect_uri: redirect_uri1,
            state: state
          }));

        }
        else {
            res.status(401).send({message: "Unauthorized", error: true})
        }
})

app.get('/slogout', async (req, res) => {
    if (req.session && req.session.passport && req.session.passport.user) {
        res.redirect('/settings')
        DBEdit.update({stoken: null, srefresh_token: null, expires_at: null, stoken_renew: false}, {where: {user: req.session.passport.user.data[0].login}})}
    else {
        res.status(401).send({message: "Unauthorized", error: true})
    }
})
app.get("/twitch_check", passport.authenticate('twitch', { scope: 'user_read' }))
app.get("/login", passport.authenticate('twitch', { scope: 'user_read' }))


app.get("/scallback" , async (req, res) => {
    
    var code = req.query.code || null;
    var state = req.query.state || null;
    var s1 = await DBEdit2.findOne({where: {state: state}})
    if (!s1) {
        res.redirect('/settings#' +
        querystring.stringify({
            error: 'state_missing'
        }));
        return
    }
    var storedState = s1.state
    log.debug(state + " / " + storedState)
    
    if (state === null || state !== storedState) {
        res.redirect('/settings#' +
        querystring.stringify({
            error: 'state_mismatch'
        }));
    } else {
        res.clearCookie(stateKey);
        var authOptions = {
      url: 'https://accounts.spotify.com/api/token',
      form: {
          code: code,
          redirect_uri: redirect_uri1,
          grant_type: 'authorization_code'
        },
        headers: {
            'Authorization': 'Basic ' + (new Buffer(sclient_id + ':' + sclient_secret).toString('base64'))
        },
        json: true
    };
    
    request.post(authOptions, async function(error, response, body) {
        if (!error && response.statusCode === 200) {
            
            var access_token = body.access_token,
            refresh_token = body.refresh_token,
            expires_in = body.expires_in;
            
            DBEdit.update({stoken: access_token, srefresh_token: refresh_token, expires_at: Date.now() + 3600000, stoken_renew: true}, {where: {user: s1.user}})
            
            var sickdelete = await DBEdit2.destroy({where: {state: state}})
            res.redirect('/settings');
            
            // we can also pass the token to the browser to make requests from ther
            
        } else {
            res.redirect('/#' +
            querystring.stringify({
                error: 'invalid_token'
            }));
        }
    });
}
})

app.get("/tcallback" , passport.authenticate('twitch', { successRedirect: '/', failureRedirect: '/#login_error' }))

app.get("/overlayinfo/", async (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    const user = req.query.user
    if (!user) {
        res.status(404).send({message: "No user provided", error: true})
        return
    }
    var dbuser = await DBEdit.findOne({where: {user: user}})
    log.debug(dbuser)
    if (!dbuser) {
        res.status(404).send({message: "No user exists", error: true})
        return
    }

    res.json({message: "Hello, " + user, error: false})

})


app.get("/nowplaying", async (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    const user = req.query.user
    if (!user) {
        res.status(404).send({message: "No user provided", error: true})
        return
    }
    var dbuser = await DBEdit.findOne({where: {user: user}})
    if (!dbuser) {
        res.status(404).send({message: "No user exists", error: true})
        return
    }
    var requestOptions = {
        method: 'GET',
        url: 'https://api.spotify.com/v1/me/player/currently-playing',
        headers: {
            'Authorization': 'Bearer ' + dbuser.stoken
        }
    }
    request.get(requestOptions, function(error, response, body) {
        if (!error && response.statusCode === 200) {
            if (body)
            { 
                var body = JSON.parse(body)
                var song_name = body.item.name;
                var song_cover = body.item.album.images[0].url;
                var artists = body.item.artists;
                var progress = body.progress_ms,
                total = body.item.duration_ms;
                
                res.json({data: {song_name: song_name, song_cover: song_cover, artists: artists, progress: progress, totalMS: total}, error: false})}
            else {
                res.send({message: "No song playing", error: false})
            }
        } else {
            res.send({message: "Token is invalid or expired", error: true})
        }
    })

})

app.get("/logout", async (req, res) => {
    req.logout((err) => {
        if (err) {
            throw err
        }
        res.status(200).redirect('/');
    })
    
})

app.get("/settings", async (req, res) => {
    if(req.session && req.session.passport && req.session.passport.user) {
        const html = await ejs.renderFile("views/settings.ejs", {user: req.session.passport.user, DBEdit: DBEdit, DBEdit3: DBEdit3}, {async: true});
        res.send(html)
      } else {
        res.status(401).redirect('/')
      }
})

app.post("/api/settings", async (req, res) => {
    const user = await req.body.user
    const userMain = req.session.passport.user;

    if(userMain) {
        if (user == userMain.data[0].login) {

            var style = req.body.style;
            var DBdata = await DBEdit3.findOne({where: {user: user}})
            if (DBdata) {
                DBEdit3.update({style: style}, {where: {user: user}})
            } else {
                DBEdit3.create({user: user, style: style})
            }

            res.redirect('/settings')
            
        }

    } else {
        res.status(401).send({message: "Unauthorized", error: true})
    }
})


setInterval(() => {
    updateTokens()
}, 2000)

function updateTokens() {
    var data = DBEdit.findAll()
    data.then((data) => {
        for (var i = 0; i < data.length; i++) {
            var user = data[i].twitch_username
            var stoken = data[i].stoken
            var srefresh_token = data[i].srefresh_token
            var expires_at = data[i].expires_at
            var time = Date.now()

            if (time > expires_at) {
                refreshToken(user, srefresh_token) 
            }
        }
    })
}

function  refreshToken(user, srefresh_token) {
  var authOptions = {
    url: 'https://accounts.spotify.com/api/token',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      'Authorization': 'Basic ' + (new Buffer.from(sclient_id + ':' + sclient_secret).toString('base64'))
    },
    form: {
      grant_type: 'refresh_token',
      refresh_token: srefresh_token
    },
    json: true
  };

  request.post(authOptions, function(error, response, body) {
    if (!error && response.statusCode === 200) {
      var access_token = body.access_token,
          refresh_token = body.refresh_token;
        DBEdit.update({stoken: access_token, srefresh_token: refresh_token, expires_at: Date.now() + 3600000}, {where: {twitch_username: user}})
    }
  });
};


