let settings = {
    user: "",
    style: ""

}


function getSettings() {
    const styleSelect = document.getElementById('style');
    const selectedOption = styleSelect.options[styleSelect.selectedIndex].value;
    console.log(selectedOption);

    settings.user = document.getElementById('user').innerHTML;
    settings.style = selectedOption;
    saveSettings()
}

function saveSettings() {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/api/settings';

    // Create form fields
    const input1 = document.createElement('input');
    input1.type = 'hidden';
    input1.name = 'user';
    input1.value = settings.user;
    form.appendChild(input1);

    const input2 = document.createElement('input');
    input2.type = 'hidden';
    input2.name = 'style';
    input2.value = settings.style;
    form.appendChild(input2);

    // Submit the form
    document.body.appendChild(form);
    form.submit();
}